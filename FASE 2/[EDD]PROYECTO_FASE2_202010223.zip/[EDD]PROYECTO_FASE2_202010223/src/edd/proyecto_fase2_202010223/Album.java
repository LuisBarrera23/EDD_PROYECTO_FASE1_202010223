/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.proyecto_fase2_202010223;

/**
 *
 * @author angel
 */
class Album {
    public String nombre;
    public Listaimagenes imagenes;

    public Album(String nombre, Listaimagenes imagenes) {
        this.nombre = nombre;
        this.imagenes = imagenes;
    }
    
}
