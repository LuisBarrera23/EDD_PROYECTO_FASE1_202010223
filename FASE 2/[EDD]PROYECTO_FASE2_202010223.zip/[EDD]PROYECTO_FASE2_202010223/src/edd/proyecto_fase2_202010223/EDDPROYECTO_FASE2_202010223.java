package edd.proyecto_fase2_202010223;
public class EDDPROYECTO_FASE2_202010223 {
    static ListaClientes clientes=new ListaClientes();
    static ArbolB clientes2=new ArbolB();
    public static void main(String[] args) {
        Login ventana= new Login();
        ventana.setVisible(true);
    }
    
}
